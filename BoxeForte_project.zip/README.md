# Boxe Forte — Terceira Entrega (JavaScript Avançado)

**Descrição:** Projeto didático para implementar um SPA simples em JavaScript modular, com templates, validação de formulários e armazenamento local.

**Como rodar:** Basta abrir `index.html` em um servidor local (recomendado) ou com Live Server do VSCode. Também funciona abrindo diretamente no navegador em modo de arquivos, mas algumas import dynamic podem requerer servidor.

**Estrutura de pastas**
```
/BoxeForte_project/
  index.html
  css/styles.css
  js/
    router.js
    templates.js
    storage.js
    formValidation.js
    main.js
    views/
      home.js
      cursos.js
      contato.js
  images/
  README.md
```
**Tecnologias:** JavaScript (ES Modules), HTML5, CSS3, localStorage.

**Como testar validações:**
1. Navegue até /contato ou clique em "Contato".
2. Tente submeter sem preencher — mensagens de erro aparecerão.
3. Preencha um e-mail inválido (ex: `usuario@`) — verá mensagem específica.
4. Ao submeter corretamente, os dados são salvos no `localStorage` (verifique na aba Application do DevTools).

**Link público do GitHub:** (cole aqui o link do repositório público)

---
Entregue como arquivos separados conforme solicitado.
