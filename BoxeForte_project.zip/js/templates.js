// templates.js
// Autor: Aluno
// Objetivo: funções utilitárias para templates e renderização

export function escapeHTML(str = '') {
  return String(str).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

export function templateCard(data) {
  return `
    <article class="card">
      <h3>${escapeHTML(data.title)}</h3>
      <p>${escapeHTML(data.description)}</p>
    </article>
  `;
}

export function renderTo(containerSelector, htmlString) {
  const el = document.querySelector(containerSelector);
  if (el) el.innerHTML = htmlString;
}