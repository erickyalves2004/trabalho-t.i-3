// formValidation.js
// Autor: Aluno
// Objetivo: validar formulário de contato e mostrar erros
export function validateContactForm(formElement) {
  const errors = {};
  const name = formElement.querySelector('[name="nome"]').value.trim();
  const email = formElement.querySelector('[name="email"]').value.trim();
  const message = formElement.querySelector('[name="mensagem"]').value.trim();

  if (!name) errors.nome = 'Nome é obrigatório.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = 'Email inválido.';
  if (message.length < 10) errors.mensagem = 'Mensagem muito curta (mínimo 10 caracteres).';

  return errors;
}

export function clearErrors(formElement) {
  formElement.querySelectorAll('.error-text').forEach(el => el.remove());
  formElement.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));
}

export function showErrors(formElement, errors) {
  clearErrors(formElement);
  Object.keys(errors).forEach(key => {
    const field = formElement.querySelector(`[name="${key}"]`);
    if (field) {
      field.classList.add('input-error');
      const span = document.createElement('span');
      span.className = 'error-text';
      span.setAttribute('aria-live','polite');
      span.textContent = errors[key];
      field.insertAdjacentElement('afterend', span);
    }
  });
}