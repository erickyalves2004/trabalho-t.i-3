// main.js
// Autor: Aluno
// Objetivo: bootstrap da SPA, bindings e inicialização
import { bindLinks, renderRoute } from './router.js';
import { getContacts } from './storage.js';

bindLinks();
renderRoute(); // render initial route

// expose navigate to window for debugging (optional)
import('./router.js').then(m => window.navigate = m.navigate);

// small helper to show saved contacts in console (dev assist)
window.showSavedContacts = () => {
  console.table(getContacts());
};