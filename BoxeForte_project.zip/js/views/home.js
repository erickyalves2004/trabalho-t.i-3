// home.js
export default function() {
  return `
    <section>
      <h2>Bem-vindo ao Boxe Forte</h2>
      <p>Projeto didático demonstrando SPA em JavaScript modular.</p>
      <div class="card">
        <h3>Princípios</h3>
        <ul>
          <li>Modularidade</li>
          <li>Templates</li>
          <li>Validação e localStorage</li>
        </ul>
      </div>
    </section>
  `;
}