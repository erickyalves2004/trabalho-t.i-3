// cursos.js
import { templateCard } from '../templates.js';

export default function() {
  const cursos = [
    {title: 'Boxe para iniciantes', description: 'Treinos básicos e postura.'},
    {title: 'Condicionamento físico', description: 'Aprimore seu condicionamento.'},
    {title: 'Técnicas avançadas', description: 'Combinando ofensiva e defesa.'}
  ];

  return `
    <section>
      <h2>Cursos</h2>
      ${cursos.map(c => templateCard(c)).join('')}
    </section>
  `;
}