// contato.js
import { validateContactForm, showErrors, clearErrors } from '../formValidation.js';
import { saveContact, getContacts } from '../storage.js';

export default function() {
  const contacts = getContacts();
  return `
    <section>
      <h2>Contato</h2>
      <form id="contactForm" novalidate>
        <div class="form-row">
          <label>Nome<br/><input name="nome" type="text" /></label>
        </div>
        <div class="form-row">
          <label>Email<br/><input name="email" type="email" /></label>
        </div>
        <div class="form-row">
          <label>Mensagem<br/><textarea name="mensagem" rows="4"></textarea></label>
        </div>
        <div class="form-row">
          <button type="submit">Enviar</button>
        </div>
      </form>

      <h3>Contatos salvos (${contacts.length})</h3>
      <ul id="savedList">
        ${contacts.map(c => `<li><strong>${c.nome}</strong> — ${c.email}</li>`).join('')}
      </ul>
    </section>
  `;
}

// attach event handlers after mount
setTimeout(() => {
  const form = document.querySelector('#contactForm');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const errors = validateContactForm(form);
    if (Object.keys(errors).length) {
      showErrors(form, errors);
      return;
    }
    // collect values
    const data = {
      nome: form.querySelector('[name="nome"]').value.trim(),
      email: form.querySelector('[name="email"]').value.trim(),
      mensagem: form.querySelector('[name="mensagem"]').value.trim(),
      date: new Date().toISOString()
    };
    saveContact(data);
    // simple success behavior: clear form and refresh contatos list
    form.reset();
    clearErrors(form);
    // re-render the contato view to update saved list
    import('./contato.js').then(m => {
      document.querySelector('#app').innerHTML = m.default();
    });
  });
}, 60);