// storage.js
// Autor: Aluno
// Objetivo: helpers para salvar/recuperar contatos no localStorage
const STORAGE_KEY = 'boxeforte:contatos';

export function saveContact(contact) {
  const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  arr.push(contact);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

export function getContacts() {
  return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
}