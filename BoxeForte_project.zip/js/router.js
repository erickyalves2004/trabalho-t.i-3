// router.js
// Autor: Aluno
// Objetivo: Router simples para SPA (history API)
const routes = {
  '/': 'home',
  '/cursos': 'cursos',
  '/contato': 'contato'
};

export function navigate(path) {
  if (location.pathname === path) return;
  history.pushState({}, '', path);
  renderRoute(path);
}

export async function renderRoute(path = location.pathname) {
  const viewId = routes[path] || 'notfound';
  const outlet = document.querySelector('#app');
  try {
    const module = await import(`./views/${viewId}.js`);
    outlet.innerHTML = module.default();
    // move focus to main content for accessibility
    outlet.focus();
  } catch (err) {
    outlet.innerHTML = '<h2>Página não encontrada</h2>';
  }
}

window.addEventListener('popstate', () => renderRoute());

// attach link handler
export function bindLinks() {
  document.body.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-link]');
    if (!a) return;
    e.preventDefault();
    const href = a.getAttribute('href');
    navigate(href);
  });
}